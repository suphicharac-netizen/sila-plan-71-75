import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Printer,
  Menu,
  Layers
} from 'lucide-react';
import { YEARS } from '../data/initialData';
import { PlanType } from '../types';
import { ActiveView } from './Sidebar';

interface TopbarProps {
  globalFiscalYear: number;
  onSetFiscalYear: (year: number) => void;
  currentView: ActiveView;
  onNavigate: (view: ActiveView) => void;
  onToggleMobile: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  globalFiscalYear,
  onSetFiscalYear,
  currentView,
  onNavigate,
  onToggleMobile
}) => {
  const [selectedYear, setSelectedYear] = useState<number>(globalFiscalYear);

  useEffect(() => {
    setSelectedYear(globalFiscalYear);
  }, [globalFiscalYear]);

  const planTypes: { type: PlanType; view: ActiveView; label: string }[] = [
    { type: 'ฉบับแรก', view: 'plan-first', label: 'ฉบับแรก' },
    { type: 'เพิ่มเติม', view: 'plan-additional', label: 'เพิ่มเติม' },
    { type: 'เปลี่ยนแปลง', view: 'plan-change', label: 'เปลี่ยนแปลง' },
    { type: 'แก้ไข', view: 'plan-edit', label: 'แก้ไข' }
  ];

  const handleApplyYear = () => {
    onSetFiscalYear(selectedYear);
  };

  return (
    <header
      id="topbar"
      className="bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 px-3.5 lg:px-6 py-2 sticky top-0 z-30 flex flex-wrap items-center justify-between gap-2.5 shadow-2xs no-print select-none"
    >
      {/* Left section: Mobile Toggle & Fiscal Year Selector */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={onToggleMobile}
          className="lg:hidden p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200"
          aria-label="เปิดเมนู"
        >
          <Menu className="w-4 h-4" />
        </button>

        {/* Fiscal Year Selector */}
        <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1">
          <Calendar className="w-3.5 h-3.5 text-emerald-600 mr-1.5 flex-shrink-0" />
          <label htmlFor="topbar-fiscal-year" className="text-xs font-bold text-slate-700 mr-1.5 whitespace-nowrap">
            ปีงบ:
          </label>
          <select
            id="topbar-fiscal-year"
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="bg-white text-slate-800 text-xs font-bold rounded px-2 py-0.5 border border-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
          >
            {YEARS.map((y) => (
              <option key={y} value={y}>
                พ.ศ. {y}
              </option>
            ))}
          </select>
          <button
            onClick={handleApplyYear}
            className="ml-1.5 px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-2xs"
          >
            เลือก
          </button>
        </div>

        {/* Plan Edition Switcher Pills */}
        <div className="hidden sm:flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          <span className="text-[10px] font-bold text-slate-500 px-1.5 flex items-center gap-1">
            <Layers className="w-3 h-3 text-slate-400" />
            แผน:
          </span>
          {planTypes.map((pt) => {
            const isActive = currentView === pt.view;
            return (
              <button
                key={pt.type}
                onClick={() => onNavigate(pt.view)}
                className={`px-2.5 py-0.5 rounded text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-white hover:text-slate-900'
                }`}
              >
                {pt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Right section: Global Actions */}
      <div className="flex items-center gap-2">
        {/* Print Button */}
        <button
          onClick={() => window.print()}
          title="พิมพ์เอกสาร / PDF"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 transition"
        >
          <Printer className="w-3.5 h-3.5 text-slate-600" />
          <span className="hidden sm:inline">พิมพ์</span>
        </button>
      </div>
    </header>
  );
};

