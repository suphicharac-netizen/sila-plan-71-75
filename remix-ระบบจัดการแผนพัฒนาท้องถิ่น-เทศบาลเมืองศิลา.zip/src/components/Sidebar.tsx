import React from 'react';
import {
  LayoutDashboard,
  FileText,
  FilePlus,
  FileDiff,
  FileEdit,
  CheckCircle,
  Coins,
  Activity,
  BarChart3,
  Search,
  Users,
  Database,
  Building2,
  X,
  Code
} from 'lucide-react';
import { PlanType, ActiveView } from '../types';
export type { ActiveView };

interface SidebarProps {
  currentView: ActiveView;
  onNavigate: (view: ActiveView) => void;
  onOpenBackup: () => void;
  onOpenAppsScript?: () => void;
  isOpenMobile: boolean;
  onToggleMobile: () => void;
  countsByType: Record<PlanType, number>;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  onOpenBackup,
  onOpenAppsScript,
  isOpenMobile,
  onToggleMobile,
  countsByType
}) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-950/70 z-40 lg:hidden backdrop-blur-xs"
          onClick={onToggleMobile}
        />
      )}

      {/* Sidebar container */}
      <aside
        id="sidebar"
        className={`fixed lg:static top-0 left-0 bottom-0 z-50 w-64 bg-slate-900 text-slate-200 flex flex-col border-r border-slate-800 transition-transform duration-300 ease-in-out select-none ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-xs flex-shrink-0">
              <Building2 className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h1 className="text-xs font-bold text-white leading-tight truncate">
                เทศบาลเมืองศิลา
              </h1>
              <p className="text-[11px] text-emerald-400 font-semibold leading-tight">
                พ.ศ. 2571–2575
              </p>
              <p className="text-[10px] text-slate-400 truncate leading-tight">ระบบแผนพัฒนาท้องถิ่น</p>
            </div>
          </div>
          <button
            onClick={onToggleMobile}
            className="lg:hidden text-slate-400 hover:text-white p-1 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation list divided into clear sections */}
        <div className="flex-1 overflow-y-auto py-2.5 px-2.5 space-y-3 custom-scrollbar">
          {/* SECTION 1: แผนพัฒนา 5 ปี (แบบ ผ.02) */}
          <div>
            <div className="px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-400 uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                แผนพัฒนา 5 ปี (ผ.02)
              </span>
            </div>

            <div className="space-y-0.5 mt-1">
              <button
                onClick={() => {
                  onNavigate('dashboard');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'dashboard'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <LayoutDashboard className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="truncate">แดชบอร์ดภาพรวมแผน</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onNavigate('plan-first');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'plan-first'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileText className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="truncate">แผนพัฒนาท้องถิ่น ฉบับแรก</span>
                </div>
                {countsByType['ฉบับแรก'] > 0 && (
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                    {countsByType['ฉบับแรก']}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  onNavigate('plan-additional');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'plan-additional'
                    ? 'bg-sky-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <FilePlus className="w-3.5 h-3.5 text-sky-400" />
                  <span className="truncate">แผนพัฒนาท้องถิ่น ฉบับเพิ่มเติม</span>
                </div>
                {countsByType['เพิ่มเติม'] > 0 && (
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-sky-950 text-sky-300 border border-sky-700/60">
                    {countsByType['เพิ่มเติม']}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  onNavigate('plan-change');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'plan-change'
                    ? 'bg-violet-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileDiff className="w-3.5 h-3.5 text-violet-400" />
                  <span className="truncate">แผนพัฒนาท้องถิ่น ฉบับเปลี่ยนแปลง</span>
                </div>
                {countsByType['เปลี่ยนแปลง'] > 0 && (
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-violet-950 text-violet-300 border border-violet-700/60">
                    {countsByType['เปลี่ยนแปลง']}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  onNavigate('plan-edit');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'plan-edit'
                    ? 'bg-amber-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileEdit className="w-3.5 h-3.5 text-amber-400" />
                  <span className="truncate">แผนพัฒนาท้องถิ่น ฉบับแก้ไข</span>
                </div>
                {countsByType['แก้ไข'] > 0 && (
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 border border-amber-700/60">
                    {countsByType['แก้ไข']}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* CATEGORY 2: อนุมัติ & การเงิน */}
          <div className="pt-1.5 border-t border-slate-800">
            <div className="px-2 py-0.5 text-[10px] font-bold tracking-wider text-amber-400 uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                อนุมัติ & การเงิน
              </span>
            </div>

            <div className="space-y-0.5 mt-1">
              <button
                onClick={() => {
                  onNavigate('approval');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'approval'
                    ? 'bg-indigo-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <CheckCircle className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="truncate">อนุมัติประกาศใช้แผน</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onNavigate('budget-approval');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'budget-approval'
                    ? 'bg-amber-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  <span className="truncate">อนุมัติงบประมาณ</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onNavigate('tracking');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'tracking'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Activity className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="truncate">ระบบติดตามโครงการ</span>
                </div>
              </button>
            </div>
          </div>

          {/* CATEGORY 3: รายงาน & ค้นหา */}
          <div className="pt-1.5 border-t border-slate-800">
            <div className="px-2 py-0.5 text-[10px] font-bold tracking-wider text-teal-400 uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                รายงาน & การสืบค้น
              </span>
            </div>

            <div className="space-y-0.5 mt-1">
              <button
                onClick={() => {
                  onNavigate('report');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'report'
                    ? 'bg-teal-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <BarChart3 className="w-3.5 h-3.5 text-teal-400" />
                  <span className="truncate">รายงานแผนพัฒนาท้องถิ่น</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onNavigate('search');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'search'
                    ? 'bg-blue-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Search className="w-3.5 h-3.5 text-blue-400" />
                  <span className="truncate">ระบบสืบค้นโครงการ</span>
                </div>
              </button>
            </div>
          </div>

          {/* CATEGORY 4: จัดการผู้ใช้งาน */}
          <div className="pt-1.5 border-t border-slate-800">
            <div className="px-2 py-0.5 text-[10px] font-bold tracking-wider text-slate-400 uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                ผู้ใช้งาน & สิทธิ์
              </span>
            </div>

            <div className="space-y-0.5 mt-1">
              <button
                onClick={() => {
                  onNavigate('users');
                  if (isOpenMobile) onToggleMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentView === 'users'
                    ? 'bg-cyan-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Users className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="truncate">จัดการผู้ใช้งาน</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer info & Backup / GAS button */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/50 space-y-1.5">
          {onOpenAppsScript && (
            <button
              onClick={onOpenAppsScript}
              className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] font-semibold text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 hover:text-white border border-emerald-800/60 transition"
            >
              <Code className="w-3.5 h-3.5 text-emerald-400" />
              <span>Google Apps Script (GAS)</span>
            </button>
          )}

          <button
            onClick={onOpenBackup}
            className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700/80 hover:text-white border border-slate-700/60 transition"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>สำรอง / จัดการข้อมูล</span>
          </button>

          <div className="text-center text-[10px] text-slate-400">
            เทศบาลเมืองศิลา © 2571-2575
          </div>
        </div>
      </aside>
    </>
  );
};
