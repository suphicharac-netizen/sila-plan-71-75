import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  Mail,
  Phone,
  Building2,
  Trash2,
  Edit,
  X,
  Save,
  CheckCircle2,
  Ban
} from 'lucide-react';
import { UserItem } from '../types';
import { ORG_NAME } from '../data/initialData';
import { TablePagination } from './TablePagination';

interface UserManagementViewProps {
  users: UserItem[];
  onSaveUser: (data: Partial<UserItem>) => void;
  onDeleteUser: (id: number) => void;
}

export const UserManagementView: React.FC<UserManagementViewProps> = ({
  users,
  onSaveUser,
  onDeleteUser
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  const paginatedUsers = React.useMemo(() => {
    if (pageSize >= 999 || pageSize === 0) return users;
    const startIndex = (currentPage - 1) * pageSize;
    return users.slice(startIndex, startIndex + pageSize);
  }, [users, currentPage, pageSize]);

  const [name, setName] = useState('');
  const [position, setPosition] = useState('');
  const [department, setDepartment] = useState('กองยุทธศาสตร์และงบประมาณ');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserItem['สิทธิ์การใช้งาน']>('เจ้าหน้าที่บันทึกข้อมูล');
  const [status, setStatus] = useState<'ใช้งาน' | 'ระงับการใช้งาน'>('ใช้งาน');

  const handleOpenAdd = () => {
    setEditingUser(null);
    setName('');
    setPosition('');
    setDepartment('กองยุทธศาสตร์และงบประมาณ');
    setEmail('');
    setPhone('');
    setRole('เจ้าหน้าที่บันทึกข้อมูล');
    setStatus('ใช้งาน');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (u: UserItem) => {
    setEditingUser(u);
    setName(u['ชื่อ-สกุล']);
    setPosition(u['ตำแหน่ง']);
    setDepartment(u['หน่วยงาน/กอง']);
    setEmail(u['อีเมล']);
    setPhone(u['เบอร์โทรศัพท์']);
    setRole(u['สิทธิ์การใช้งาน']);
    setStatus(u['สถานะ']);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('กรุณากรอกชื่อ-สกุล');
      return;
    }

    onSaveUser({
      ID: editingUser ? editingUser.ID : undefined,
      'ชื่อ-สกุล': name.trim(),
      'ตำแหน่ง': position.trim(),
      'หน่วยงาน/กอง': department.trim(),
      'อีเมล': email.trim(),
      'เบอร์โทรศัพท์': phone.trim(),
      'สิทธิ์การใช้งาน': role,
      'สถานะ': status
    });

    setIsModalOpen(false);
  };

  const getRoleBadge = (r: string) => {
    let color = 'bg-slate-100 text-slate-800 border-slate-200';
    if (r === 'ผู้ดูแลระบบ') color = 'bg-rose-100 text-rose-800 border-rose-200';
    if (r === 'ผู้บริหาร/ผู้อนุมัติ') color = 'bg-purple-100 text-purple-800 border-purple-200';
    if (r === 'เจ้าหน้าที่บันทึกข้อมูล') color = 'bg-emerald-100 text-emerald-800 border-emerald-200';

    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold border ${color}`}>
        <ShieldCheck className="w-3 h-3" />
        {r}
      </span>
    );
  };

  const getStatusBadge = (st: string) => {
    if (st === 'ใช้งาน') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
          ใช้งาน
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-200">
        <Ban className="w-3 h-3 text-rose-600" />
        ระงับการใช้งาน
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-xl p-3.5 sm:p-4 border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
              ระบบจัดการผู้ใช้งานและสิทธิ์การเข้าถึง
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              จัดการรายชื่อเจ้าหน้าที่, ผู้อนุมัติ และกำหนดระดับสิทธิ์ในระบบแผนพัฒนาท้องถิ่น {ORG_NAME}
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-2xs transition"
        >
          <UserPlus className="w-3.5 h-3.5" />
          เพิ่มผู้ใช้งานใหม่
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-800 text-white border-b border-slate-700">
                <th className="py-2 px-2.5 text-center w-12 font-bold">ที่</th>
                <th className="py-2 px-2.5 font-bold">ชื่อ-สกุล</th>
                <th className="py-2 px-2.5 font-bold">ตำแหน่ง</th>
                <th className="py-2 px-2.5 font-bold">หน่วยงาน / กอง</th>
                <th className="py-2 px-2.5 font-bold">ข้อมูลการติดต่อ</th>
                <th className="py-2 px-2.5 font-bold">สิทธิ์การใช้งาน</th>
                <th className="py-2 px-2.5 font-bold text-center">สถานะ</th>
                <th className="py-2 px-2.5 font-bold text-center w-20">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedUsers.length > 0 ? (
                paginatedUsers.map((u, idx) => {
                  const globalIdx = (pageSize >= 999 || pageSize === 0 ? 0 : (currentPage - 1) * pageSize) + idx;
                  return (
                    <tr key={u.ID} className="hover:bg-slate-50 transition">
                      <td className="py-2 px-2.5 text-center font-bold text-slate-900 font-mono">{globalIdx + 1}</td>
                      <td className="py-2 px-2.5 font-bold text-slate-900">{u['ชื่อ-สกุล']}</td>
                      <td className="py-2 px-2.5 text-slate-700 font-medium">{u['ตำแหน่ง'] || '-'}</td>
                      <td className="py-2 px-2.5 text-slate-700">{u['หน่วยงาน/กอง'] || '-'}</td>
                      <td className="py-2 px-2.5 space-y-0.5">
                        {u['อีเมล'] && (
                          <div className="flex items-center gap-1.5 text-slate-600 text-[11px]">
                            <Mail className="w-2.5 h-2.5 text-slate-400" />
                            <span>{u['อีเมล']}</span>
                          </div>
                        )}
                        {u['เบอร์โทรศัพท์'] && (
                          <div className="flex items-center gap-1.5 text-slate-600 text-[11px]">
                            <Phone className="w-2.5 h-2.5 text-slate-400" />
                            <span>{u['เบอร์โทรศัพท์']}</span>
                          </div>
                        )}
                      </td>
                      <td className="py-2 px-2.5">{getRoleBadge(u['สิทธิ์การใช้งาน'])}</td>
                      <td className="py-2 px-2.5 text-center">{getStatusBadge(u['สถานะ'])}</td>
                      <td className="py-2 px-2.5 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => handleOpenEdit(u)}
                            className="p-1 rounded bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 transition"
                            title="แก้ไขผู้ใช้งาน"
                          >
                            <Edit className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`ยืนยันการลบผู้ใช้งาน ${u['ชื่อ-สกุล']} หรือไม่?`)) {
                                onDeleteUser(u.ID);
                              }
                            }}
                            className="p-1 rounded bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition"
                            title="ลบผู้ใช้งาน"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-slate-400 text-xs">
                    ยังไม่มีข้อมูลผู้ใช้งาน
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer - Standard Pagination */}
        {users.length > 0 && (
          <TablePagination
            currentPage={currentPage}
            totalItems={users.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
            pageSizeOptions={[10, 20, 50, 100, 999]}
          />
        )}
      </div>

      {/* Modal User Form */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/70 z-50 flex items-center justify-center p-3 backdrop-blur-2xs">
          <div className="bg-white rounded-xl max-w-lg w-full p-4 sm:p-5 shadow-xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-600" />
                {editingUser ? 'แก้ไขข้อมูลผู้ใช้งาน' : 'เพิ่มผู้ใช้งานใหม่'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">
                    ชื่อ-สกุล <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="เช่น นายสมศักดิ์ นามศิลา"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">ตำแหน่ง</label>
                  <input
                    type="text"
                    placeholder="เช่น นักวิเคราะห์นโยบายและแผน"
                    value={position}
                    onChange={(e) => setPosition(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">หน่วยงาน / กอง</label>
                  <input
                    type="text"
                    placeholder="เช่น กองยุทธศาสตร์และงบประมาณ"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">อีเมล</label>
                  <input
                    type="email"
                    placeholder="user@sila.go.th"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">เบอร์โทรศัพท์</label>
                  <input
                    type="text"
                    placeholder="043-246-888"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">สิทธิ์การใช้งาน</label>
                  <select
                    value={role}
                    onChange={(e) =>
                      setRole(e.target.value as UserItem['สิทธิ์การใช้งาน'])
                    }
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="เจ้าหน้าที่บันทึกข้อมูล">เจ้าหน้าที่บันทึกข้อมูล</option>
                    <option value="ผู้ดูแลระบบ">ผู้ดูแลระบบ</option>
                    <option value="ผู้บริหาร/ผู้อนุมัติ">ผู้บริหาร/ผู้อนุมัติ</option>
                    <option value="ผู้ใช้งานทั่วไป">ผู้ใช้งานทั่วไป</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">สถานะการใช้งาน</label>
                  <select
                    value={status}
                    onChange={(e) =>
                      setStatus(e.target.value as 'ใช้งาน' | 'ระงับการใช้งาน')
                    }
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="ใช้งาน">ใช้งาน</option>
                    <option value="ระงับการใช้งาน">ระงับการใช้งาน</option>
                  </select>
                </div>
              </div>

              <div className="pt-2.5 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition text-xs"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-2xs transition text-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  บันทึกข้อมูล
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
