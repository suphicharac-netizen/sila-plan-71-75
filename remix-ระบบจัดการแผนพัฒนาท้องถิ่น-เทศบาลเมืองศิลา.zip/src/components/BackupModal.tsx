import React, { useState } from 'react';
import {
  Database,
  Download,
  Upload,
  RotateCcw,
  X,
  CheckCircle2,
  AlertTriangle,
  FileJson
} from 'lucide-react';
import { StorageService } from '../services/storageService';

interface BackupModalProps {
  onClose: () => void;
  onRefreshAll: () => void;
  onShowToast: (title: string, msg?: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({
  onClose,
  onRefreshAll,
  onShowToast
}) => {
  const [importJson, setImportJson] = useState('');

  const handleExport = () => {
    const data = StorageService.exportAllData();
    const str = JSON.stringify(data, null, 2);
    const blob = new Blob([str], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sila_plan_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    onShowToast('ส่งออกข้อมูลสำเร็จ', 'ดาวน์โหลดไฟล์สำรองข้อมูล JSON เรียบร้อย');
  };

  const handleImport = () => {
    if (!importJson.trim()) {
      alert('กรุณาวางข้อความ JSON ข้อมูลสำรอง');
      return;
    }
    const success = StorageService.importAllData(importJson);
    if (success) {
      onShowToast('นำเข้าข้อมูลสำเร็จ', 'ข้อมูลระบบได้รับการอัปเดตเรียบร้อย');
      onRefreshAll();
      onClose();
    } else {
      onShowToast('นำเข้าข้อมูลล้มเหลว', 'รูปแบบ JSON ไม่ถูกต้อง', 'error');
    }
  };

  const handleReset = () => {
    if (
      confirm(
        'คุณแน่ใจหรือไม่ว่าต้องการคืนค่าข้อมูลเริ่มต้นของเทศบาลเมืองศิลา? ข้อมูลที่แก้ไขล่าสุดจะถูกแทนที่ด้วยข้อมูลชุดเริ่มต้น'
      )
    ) {
      StorageService.resetToDefaultData();
      onShowToast('คืนค่าข้อมูลเริ่มต้นเรียบร้อย', 'โหลดข้อมูลตัวอย่างเทศบาลเมืองศิลาครบถ้วน');
      onRefreshAll();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 z-50 flex items-center justify-center p-3 backdrop-blur-2xs">
      <div className="bg-white rounded-xl max-w-lg w-full p-4 sm:p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3.5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Database className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-tight">สำรองและจัดการข้อมูลระบบ</h3>
              <p className="text-[10px] text-slate-500">แผนพัฒนาท้องถิ่น (พ.ศ. 2571-2575)</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 p-1 rounded-md">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          {/* Export section */}
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
            <div>
              <div className="font-bold text-slate-800 text-xs">สำรองข้อมูลทั้งหมด (Export JSON)</div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                ดาวน์โหลดไฟล์ข้อมูลโครงการ, การอนุมัติ, งบประมาณ, ผู้ใช้งาน
              </div>
            </div>
            <button
              onClick={handleExport}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold transition shadow-2xs flex-shrink-0 text-xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              ดาวน์โหลด
            </button>
          </div>

          {/* Import section */}
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
            <div className="font-bold text-slate-800 text-xs">นำเข้าข้อมูลสำรอง (Import JSON)</div>
            <textarea
              rows={3}
              placeholder="วางข้อความ JSON ที่สำรองไว้ที่นี่..."
              value={importJson}
              onChange={(e) => setImportJson(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-[11px] text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            <div className="flex justify-end">
              <button
                onClick={handleImport}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition shadow-2xs text-xs"
              >
                <Upload className="w-3.5 h-3.5" />
                นำเข้าข้อมูล
              </button>
            </div>
          </div>

          {/* Reset section */}
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-between gap-3">
            <div>
              <div className="font-bold text-rose-900 text-xs">คืนค่าข้อมูลเริ่มต้น (Reset Data)</div>
              <div className="text-rose-700/80 text-[11px] mt-0.5">
                รีเซ็ตข้อมูลทั้งหมดกลับสู่ชุดข้อมูลตัวอย่างเทศบาลเมืองศิลา
              </div>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold transition shadow-2xs flex-shrink-0 text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              คืนค่าเริ่มต้น
            </button>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex justify-end mt-3.5">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition text-xs"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
