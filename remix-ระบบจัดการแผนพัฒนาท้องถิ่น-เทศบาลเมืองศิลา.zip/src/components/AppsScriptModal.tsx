import React, { useState } from 'react';
import {
  Code,
  Copy,
  Check,
  Download,
  ExternalLink,
  FileSpreadsheet,
  Layers,
  Sparkles,
  Zap,
  BookOpen,
  X,
  RefreshCw,
  Send
} from 'lucide-react';

interface AppsScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const APPS_SCRIPT_CODE = `/**
 * ==============================================================================
 * ระบบติดตามและบริหารแผนพัฒนาท้องถิ่น (พ.ศ. 2571-2575) เทศบาลเมืองศิลา
 * GOOGLE APPS SCRIPT (GAS) BACKEND & GOOGLE SHEETS CONNECTOR (Code.gs)
 * ==============================================================================
 * คำแนะนำ:
 * 1. ไปที่ Google Sheets -> เมนู "ส่วนขยาย" (Extensions) -> "Apps Script"
 * 2. ลบโค้ดเดิมทั้งหมดในไฟล์ Code.gs แล้ววางโค้ดชุดนี้ลงไป
 * 3. กดบันทึก (Ctrl + S)
 * 4. เลือกฟังก์ชัน "initialSetup" แล้วกด "เรียกใช้" (Run) เพื่อสร้างโครงสร้างชีตอัตโนมัติ
 * 5. กด "ทำให้ใช้งานได้" (Deploy) -> "การทำให้ใช้งานได้รายการใหม่" (New deployment)
 *    - เลือกประเภท: "เว็บแอป" (Web app)
 *    - ผู้มีสิทธิ์เข้าถึง: "ทุกคน" (Anyone)
 * ==============================================================================
 */

// ชื่อแท็บชีตต่างๆ ในระบบ
const SHEET_NAMES = {
  PROJECTS: 'Projects',
  PLAN_APPROVALS: 'PlanApprovals',
  BUDGET_APPROVALS: 'BudgetApprovals',
  USERS: 'Users',
  OPTIONS: 'Options',
  FORM_01: 'รายงาน ผ.01',
  FORM_02: 'แบบ ผ.02'
};

/**
 * 1. สร้างเมนูคำสั่งพิเศษบน Google Sheets เมื่อเปิดไฟล์
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🚀 ระบบแผนพัฒนาท้องถิ่น')
    .addItem('⚙️ ติดตั้งโครงสร้างชีตทั้งหมด (Initial Setup)', 'initialSetup')
    .addSeparator()
    .addItem('📊 ประมวลผลรายงานสรุป ผ.01', 'generateReport01')
    .addItem('📑 จัดทำแบบ ผ.02 (โครงการ 5 ปี)', 'generateReport02')
    .addSeparator()
    .addItem('📥 นำเข้าชุดข้อมูลตัวอย่าง (Load Demo Data)', 'seedInitialData')
    .addItem('🔄 ล้างข้อมูลทดสอบทั้งหมด (Reset)', 'resetAllSheets')
    .addToUi();
}

/**
 * 2. ติดตั้งแท็บและโครงสร้างตารางฐานข้อมูลอัตโนมัติ (Headers & Formatting)
 */
function initialSetup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. ชีต Projects
  let pSheet = ss.getSheetByName(SHEET_NAMES.PROJECTS);
  if (!pSheet) pSheet = ss.insertSheet(SHEET_NAMES.PROJECTS);
  pSheet.clear();
  
  const projectHeaders = [
    'ID', 'ปี พ.ศ.', 'ประเด็นการพัฒนา', 'แผนงาน', 'ชื่อโครงการ', 'วัตถุประสงค์',
    'เป้าหมาย (ผลผลิต)', 'งบประมาณ 2571', 'งบประมาณ 2572', 'งบประมาณ 2573',
    'งบประมาณ 2574', 'งบประมาณ 2575', 'รวมงบประมาณ 5 ปี', 'ผลที่คาดว่าจะได้รับ',
    'หน่วยงานรับผิดชอบหลัก', 'ประเภทรายการ', 'สถานะดำเนินงาน', 'เหตุผลและความจำเป็น',
    'ชื่อโครงการ (เดิม)', 'วัตถุประสงค์ (เดิม)', 'เป้าหมาย (เดิม)',
    'งบประมาณ 2571 (เดิม)', 'งบประมาณ 2572 (เดิม)', 'งบประมาณ 2573 (เดิม)',
    'งบประมาณ 2574 (เดิม)', 'งบประมาณ 2575 (เดิม)', 'ผลที่คาดว่าจะได้รับ (เดิม)',
    'หน่วยงานรับผิดชอบหลัก (เดิม)', 'วันที่บันทึก', 'วันที่แก้ไขล่าสุด'
  ];
  pSheet.getRange(1, 1, 1, projectHeaders.length).setValues([projectHeaders]);
  formatHeaderRow(pSheet, projectHeaders.length, '#047857'); // Emerald-700
  pSheet.setFrozenRows(1);
  
  // 2. ชีต PlanApprovals
  let aSheet = ss.getSheetByName(SHEET_NAMES.PLAN_APPROVALS);
  if (!aSheet) aSheet = ss.insertSheet(SHEET_NAMES.PLAN_APPROVALS);
  aSheet.clear();
  const approvalHeaders = [
    'ID', 'ประเภท', 'ครั้งที่', 'ปี พ.ศ.', 'วันที่อนุมัติประกาศใช้', 'ProjectIDs', 'บันทึกเพิ่มเติม', 'วันที่บันทึก'
  ];
  aSheet.getRange(1, 1, 1, approvalHeaders.length).setValues([approvalHeaders]);
  formatHeaderRow(aSheet, approvalHeaders.length, '#1e293b'); // Slate-800
  aSheet.setFrozenRows(1);

  // 3. ชีต BudgetApprovals
  let bSheet = ss.getSheetByName(SHEET_NAMES.BUDGET_APPROVALS);
  if (!bSheet) bSheet = ss.insertSheet(SHEET_NAMES.BUDGET_APPROVALS);
  bSheet.clear();
  const budgetHeaders = [
    'ID', 'ปีงบประมาณ', 'วันที่อนุมัติงบประมาณ', 'จำนวนงบประมาณที่อนุมัติ (บาท)', 'มติ/หน่วยงานผู้อนุมัติ', 'บันทึกเพิ่มเติม', 'วันที่บันทึก'
  ];
  bSheet.getRange(1, 1, 1, budgetHeaders.length).setValues([budgetHeaders]);
  formatHeaderRow(bSheet, budgetHeaders.length, '#0369a1'); // Sky-700
  bSheet.setFrozenRows(1);

  // 4. ชีต Users
  let uSheet = ss.getSheetByName(SHEET_NAMES.USERS);
  if (!uSheet) uSheet = ss.insertSheet(SHEET_NAMES.USERS);
  uSheet.clear();
  const userHeaders = [
    'ID', 'ชื่อ-สกุล', 'ตำแหน่ง', 'หน่วยงาน/กอง', 'อีเมล', 'เบอร์โทรศัพท์', 'สิทธิ์การใช้งาน', 'สถานะ', 'วันที่บันทึก'
  ];
  uSheet.getRange(1, 1, 1, userHeaders.length).setValues([userHeaders]);
  formatHeaderRow(uSheet, userHeaders.length, '#4338ca'); // Indigo-700
  uSheet.setFrozenRows(1);

  // 5. ชีต Options
  let oSheet = ss.getSheetByName(SHEET_NAMES.OPTIONS);
  if (!oSheet) oSheet = ss.insertSheet(SHEET_NAMES.OPTIONS);
  oSheet.clear();
  const optHeaders = ['หมวดหมู่', 'รายการตัวเลือก'];
  oSheet.getRange(1, 1, 1, optHeaders.length).setValues([optHeaders]);
  formatHeaderRow(oSheet, optHeaders.length, '#475569'); // Slate-600
  oSheet.setFrozenRows(1);

  SpreadsheetApp.getActiveSpreadsheet().toast('✅ ติดตั้งโครงสร้างตารางฐานข้อมูลเรียบร้อยแล้ว', 'สำเร็จ', 5);
}

/**
 * ฟังก์ชันตกแต่ง Header Row
 */
function formatHeaderRow(sheet, colCount, hexColor) {
  const header = sheet.getRange(1, 1, 1, colCount);
  header.setBackground(hexColor)
        .setFontColor('#FFFFFF')
        .setFontWeight('bold')
        .setFontFamily('Sarabun')
        .setFontSize(10)
        .setHorizontalAlignment('center')
        .setVerticalAlignment('middle');
  sheet.setRowHeight(1, 32);
}

/**
 * 3. WEB APP API (doGet & doPost)
 * สำหรับเชื่อมต่อกับ Frontend Web Application แบบ Real-time
 */
function doGet(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) || 'getAllData';
    let result = {};

    switch (action) {
      case 'getAllData':
        result = {
          status: 'success',
          projects: getTableData(SHEET_NAMES.PROJECTS),
          approvals: getTableData(SHEET_NAMES.PLAN_APPROVALS),
          budgetApprovals: getTableData(SHEET_NAMES.BUDGET_APPROVALS),
          users: getTableData(SHEET_NAMES.USERS),
          options: getOptionsData()
        };
        break;

      case 'getProjects':
        result = { status: 'success', data: getTableData(SHEET_NAMES.PROJECTS) };
        break;

      case 'getApprovals':
        result = { status: 'success', data: getTableData(SHEET_NAMES.PLAN_APPROVALS) };
        break;

      case 'getBudgetApprovals':
        result = { status: 'success', data: getTableData(SHEET_NAMES.BUDGET_APPROVALS) };
        break;

      default:
        result = { status: 'error', message: 'Invalid action: ' + action };
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doPost(e) {
  try {
    const postData = JSON.parse(e.postData.contents);
    const action = postData.action;
    let result = {};

    if (action === 'saveProject') {
      result = saveProjectRecord(postData.data);
    } else if (action === 'deleteProject') {
      result = deleteProjectRecord(postData.id);
    } else if (action === 'saveApproval') {
      result = saveApprovalRecord(postData.data);
    } else if (action === 'saveBudgetApproval') {
      result = saveBudgetApprovalRecord(postData.data);
    } else if (action === 'saveUser') {
      result = saveUserRecord(postData.data);
    } else if (action === 'bulkSync') {
      result = bulkSyncAllData(postData.data);
    } else {
      result = { status: 'error', message: 'Unknown post action' };
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * 4. Helper ฟังก์ชันอ่านข้อมูลจากตาราง (Header -> Objects)
 */
function getTableData(sheetName) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow <= 1 || lastCol === 0) return [];

  const headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  const rows = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();

  return rows.map((row) => {
    const obj = {};
    headers.forEach((h, idx) => {
      if (h) {
        let val = row[idx];
        if (val instanceof Date) {
          val = Utilities.formatDate(val, 'Asia/Bangkok', 'yyyy-MM-dd');
        }
        obj[h] = val;
      }
    });
    return obj;
  });
}

function getOptionsData() {
  const rows = getTableData(SHEET_NAMES.OPTIONS);
  const options = {};
  rows.forEach((r) => {
    const cat = r['หมวดหมู่'];
    const item = r['รายการตัวเลือก'];
    if (cat && item) {
      if (!options[cat]) options[cat] = [];
      if (!options[cat].includes(item)) options[cat].push(item);
    }
  });
  return options;
}

/**
 * 5. ฟังก์ชันบันทึกและอัปเดตข้อมูลโครงการ (Projects CRUD)
 */
function saveProjectRecord(projectData) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.PROJECTS);
  if (!sheet) initialSetup();

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const lastRow = sheet.getLastRow();

  let targetRow = -1;
  let targetId = projectData.ID;

  if (targetId) {
    // หา Row เดิมเพื่อแก้ไข
    const idCol = headers.indexOf('ID') + 1;
    if (lastRow > 1 && idCol > 0) {
      const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
      for (let i = 0; i < ids.length; i++) {
        if (String(ids[i][0]) === String(targetId)) {
          targetRow = i + 2;
          break;
        }
      }
    }
  }

  const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'dd/MM/yyyy HH:mm');

  // คำนวณงบประมาณรวม 5 ปี
  const b71 = Number(projectData['งบประมาณ 2571']) || 0;
  const b72 = Number(projectData['งบประมาณ 2572']) || 0;
  const b73 = Number(projectData['งบประมาณ 2573']) || 0;
  const b74 = Number(projectData['งบประมาณ 2574']) || 0;
  const b75 = Number(projectData['งบประมาณ 2575']) || 0;
  const totalBudget = b71 + b72 + b73 + b74 + b75;

  if (targetRow === -1) {
    // สร้าง ID ใหม่
    if (!targetId) {
      targetId = generateNextId(sheet);
    }
    projectData.ID = targetId;
    projectData['รวมงบประมาณ 5 ปี'] = totalBudget;
    projectData['วันที่บันทึก'] = nowStr;
    projectData['วันที่แก้ไขล่าสุด'] = nowStr;

    const newRow = headers.map(h => projectData[h] !== undefined ? projectData[h] : '');
    sheet.appendRow(newRow);
    return { status: 'created', id: targetId, message: 'เพิ่มโครงการใหม่สำเร็จ' };
  } else {
    // อัปเดตแถวเดิม
    projectData['รวมงบประมาณ 5 ปี'] = totalBudget;
    projectData['วันที่แก้ไขล่าสุด'] = nowStr;
    
    const updateRow = headers.map(h => projectData[h] !== undefined ? projectData[h] : '');
    sheet.getRange(targetRow, 1, 1, headers.length).setValues([updateRow]);
    return { status: 'updated', id: targetId, message: 'ปรับปรุงข้อมูลโครงการสำเร็จ' };
  }
}

function deleteProjectRecord(id) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.PROJECTS);
  if (!sheet) return { status: 'error', message: 'Sheet not found' };

  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: 'error', message: 'No records to delete' };

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const idCol = headers.indexOf('ID') + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();

  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) {
      sheet.deleteRow(i + 2);
      return { status: 'deleted', id: id, message: 'ลบโครงการเรียบร้อยแล้ว' };
    }
  }
  return { status: 'not_found', id: id, message: 'ไม่พบโครงการที่ต้องการลบ' };
}

function generateNextId(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return 1;
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const idCol = headers.indexOf('ID') + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues().map(r => Number(r[0]) || 0);
  const maxId = Math.max(...ids, 0);
  return maxId + 1;
}

/**
 * 6. สร้างและส่งออกรายงานสรุป ผ.01 อัตโนมัติใน Google Sheets
 */
function generateReport01() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAMES.FORM_01);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAMES.FORM_01);
  sheet.clear();

  const projects = getTableData(SHEET_NAMES.PROJECTS);
  const years = [2571, 2572, 2573, 2574, 2575];

  // รวบรวมประเด็นการพัฒนา
  const issueMap = {};
  projects.forEach(p => {
    const issue = p['ประเด็นการพัฒนา'] || 'ยุทธศาสตร์อื่นๆ';
    if (!issueMap[issue]) {
      issueMap[issue] = { 2571: { c: 0, b: 0 }, 2572: { c: 0, b: 0 }, 2573: { c: 0, b: 0 }, 2574: { c: 0, b: 0 }, 2575: { c: 0, b: 0 } };
    }
    const py = Number(p['ปี พ.ศ.']);
    const b71 = Number(p['งบประมาณ 2571']) || 0;
    const b72 = Number(p['งบประมาณ 2572']) || 0;
    const b73 = Number(p['งบประมาณ 2573']) || 0;
    const b74 = Number(p['งบประมาณ 2574']) || 0;
    const b75 = Number(p['งบประมาณ 2575']) || 0;

    if (b71 > 0 || py === 2571) { issueMap[issue][2571].c++; issueMap[issue][2571].b += b71; }
    if (b72 > 0 || py === 2572) { issueMap[issue][2572].c++; issueMap[issue][2572].b += b72; }
    if (b73 > 0 || py === 2573) { issueMap[issue][2573].c++; issueMap[issue][2573].b += b73; }
    if (b74 > 0 || py === 2574) { issueMap[issue][2574].c++; issueMap[issue][2574].b += b74; }
    if (b75 > 0 || py === 2575) { issueMap[issue][2575].c++; issueMap[issue][2575].b += b75; }
  });

  // เขียน Header รายงาน ผ.01
  sheet.getRange('A1:L1').merge().setValue('แบบ ผ.01 สรุปจำนวนโครงการและงบประมาณตามแผนพัฒนาท้องถิ่น (พ.ศ. 2571 - 2575)')
    .setFontWeight('bold').setFontSize(14).setHorizontalAlignment('center');
  sheet.getRange('A2:L2').merge().setValue('เทศบาลเมืองศิลา อำเภอเมืองขอนแก่น จังหวัดขอนแก่น')
    .setFontSize(11).setHorizontalAlignment('center');

  // ตารางหัวคอลัมน์
  const headRows = [
    ['ลำดับ', 'ประเด็นการพัฒนา', 'พ.ศ. 2571', '', 'พ.ศ. 2572', '', 'พ.ศ. 2573', '', 'พ.ศ. 2574', '', 'พ.ศ. 2575', ''],
    ['', '', 'จำนวน', 'งบประมาณ', 'จำนวน', 'งบประมาณ', 'จำนวน', 'งบประมาณ', 'จำนวน', 'งบประมาณ', 'จำนวน', 'งบประมาณ']
  ];
  sheet.getRange(4, 1, 2, 12).setValues(headRows);
  sheet.getRange(4, 1, 2, 1).merge();
  sheet.getRange(4, 2, 2, 1).merge();
  sheet.getRange(4, 3, 1, 2).merge();
  sheet.getRange(4, 5, 1, 2).merge();
  sheet.getRange(4, 7, 1, 2).merge();
  sheet.getRange(4, 9, 1, 2).merge();
  sheet.getRange(4, 11, 1, 2).merge();

  sheet.getRange(4, 1, 2, 12).setBackground('#065f46').setFontColor('#FFFFFF').setFontWeight('bold').setHorizontalAlignment('center');

  // ใส่แถวข้อมูล
  let rowIdx = 6;
  let seq = 1;
  const issues = Object.keys(issueMap);
  issues.forEach(iss => {
    const row = [
      seq++,
      iss,
      issueMap[iss][2571].c, issueMap[iss][2571].b,
      issueMap[iss][2572].c, issueMap[iss][2572].b,
      issueMap[iss][2573].c, issueMap[iss][2573].b,
      issueMap[iss][2574].c, issueMap[iss][2574].b,
      issueMap[iss][2575].c, issueMap[iss][2575].b
    ];
    sheet.getRange(rowIdx, 1, 1, 12).setValues([row]);
    rowIdx++;
  });

  // แถวรวม
  if (issues.length > 0) {
    sheet.getRange(rowIdx, 1, 1, 2).merge().setValue('รวมทั้งสิ้น').setFontWeight('bold').setHorizontalAlignment('center');
    for (let c = 3; c <= 12; c++) {
      const colLetter = String.fromCharCode(64 + c);
      sheet.getRange(rowIdx, c).setFormula(\`=SUM(\${colLetter}6:\${colLetter}\${rowIdx-1})\`).setFontWeight('bold');
    }
    sheet.getRange(rowIdx, 1, 1, 12).setBackground('#e2e8f0');
  }

  // Format ตัวเลขเงิน
  sheet.getRange(6, 4, rowIdx - 5, 1).setNumberFormat('#,##0');
  sheet.getRange(6, 6, rowIdx - 5, 1).setNumberFormat('#,##0');
  sheet.getRange(6, 8, rowIdx - 5, 1).setNumberFormat('#,##0');
  sheet.getRange(6, 10, rowIdx - 5, 1).setNumberFormat('#,##0');
  sheet.getRange(6, 12, rowIdx - 5, 1).setNumberFormat('#,##0');

  SpreadsheetApp.getActiveSpreadsheet().toast('📊 จัดทำรายงานสรุป ผ.01 เรียบร้อยแล้ว', 'สำเร็จ', 5);
}

/**
 * 7. จัดทำแบบ ผ.02 โครงการ 5 ปี
 */
function generateReport02() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAMES.FORM_02);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAMES.FORM_02);
  sheet.clear();

  const projects = getTableData(SHEET_NAMES.PROJECTS);

  sheet.getRange('A1:N1').merge().setValue('แบบ ผ.02 รายละเอียดโครงการพัฒนา แผนพัฒนาท้องถิ่น (พ.ศ. 2571 - 2575)')
    .setFontWeight('bold').setFontSize(13).setHorizontalAlignment('center');
  sheet.getRange('A2:N2').merge().setValue('เทศบาลเมืองศิลา อำเภอเมืองขอนแก่น จังหวัดขอนแก่น')
    .setFontSize(11).setHorizontalAlignment('center');

  const headers = [
    'ที่', 'ยุทธศาสตร์/โครงการ', 'วัตถุประสงค์', 'เป้าหมาย (ผลผลิต)',
    '2571', '2572', '2573', '2574', '2575',
    'รวม 5 ปี', 'ผลที่คาดว่าจะได้รับ', 'หน่วยงานรับผิดชอบ', 'ประเภทรายการ', 'สถานะ'
  ];

  sheet.getRange(4, 1, 1, headers.length).setValues([headers]);
  formatHeaderRow(sheet, headers.length, '#1e293b');

  if (projects.length > 0) {
    const dataRows = projects.map((p, idx) => {
      const b71 = Number(p['งบประมาณ 2571']) || 0;
      const b72 = Number(p['งบประมาณ 2572']) || 0;
      const b73 = Number(p['งบประมาณ 2573']) || 0;
      const b74 = Number(p['งบประมาณ 2574']) || 0;
      const b75 = Number(p['งบประมาณ 2575']) || 0;
      return [
        idx + 1,
        p['ชื่อโครงการ'],
        p['วัตถุประสงค์'] || '',
        p['เป้าหมาย (ผลผลิต)'] || '',
        b71, b72, b73, b74, b75,
        (b71 + b72 + b73 + b74 + b75),
        p['ผลที่คาดว่าจะได้รับ'] || '',
        p['หน่วยงานรับผิดชอบหลัก'] || '',
        p['ประเภทรายการ'] || 'ฉบับแรก',
        p['สถานะดำเนินงาน'] || 'อยู่ระหว่างดำเนินการ'
      ];
    });

    sheet.getRange(5, 1, dataRows.length, headers.length).setValues(dataRows);
    sheet.getRange(5, 5, dataRows.length, 6).setNumberFormat('#,##0');
  }

  SpreadsheetApp.getActiveSpreadsheet().toast('📑 จัดทำแบบ ผ.02 เรียบร้อยแล้ว', 'สำเร็จ', 5);
}

/**
 * 8. นำเข้าข้อมูลตัวอย่าง (Demo Data Seeder)
 */
function seedInitialData() {
  initialSetup();
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // เพิ่ม Options ตัวอย่าง
  const optSheet = ss.getSheetByName(SHEET_NAMES.OPTIONS);
  const sampleOptions = [
    ['ประเด็นการพัฒนา', '1. การพัฒนาโครงสร้างพื้นฐานและผังเมือง'],
    ['ประเด็นการพัฒนา', '2. การส่งเสริมคุณภาพชีวิตและการศึกษา'],
    ['ประเด็นการพัฒนา', '3. การจัดการทรัพยากรธรรมชาติและสิ่งแวดล้อม'],
    ['ประเด็นการพัฒนา', '4. การส่งเสริมเศรษฐกิจ การท่องเที่ยว และนวัตกรรม'],
    ['ประเด็นการพัฒนา', '5. การบริหารจัดการบ้านเมืองที่ดีและการบริการภาครัฐ'],
    ['แผนงาน', 'แผนงานเคหะและชุมชน'],
    ['แผนงาน', 'แผนงานการศึกษา'],
    ['แผนงาน', 'แผนงานสาธารณสุข'],
    ['แผนงาน', 'แผนงานการเกษตร'],
    ['แผนงาน', 'แผนงานสร้างความเข้มแข็งของชุมชน'],
    ['หน่วยงานรับผิดชอบหลัก', 'กองช่าง'],
    ['หน่วยงานรับผิดชอบหลัก', 'กองการศึกษา'],
    ['หน่วยงานรับผิดชอบหลัก', 'กองสาธารณสุขและสิ่งแวดล้อม'],
    ['หน่วยงานรับผิดชอบหลัก', 'กองสวัสดิการสังคม'],
    ['หน่วยงานรับผิดชอบหลัก', 'สำนักปลัดเทศบาล']
  ];
  optSheet.getRange(2, 1, sampleOptions.length, 2).setValues(sampleOptions);

  // เพิ่มโครงการตัวอย่าง
  saveProjectRecord({
    ID: 1,
    'ปี พ.ศ.': 2571,
    'ประเด็นการพัฒนา': '1. การพัฒนาโครงสร้างพื้นฐานและผังเมือง',
    'แผนงาน': 'แผนงานเคหะและชุมชน',
    'ชื่อโครงการ': 'โครงการก่อสร้างถนนคอนกรีตเสริมเหล็ก ซอยศิลาพัฒนา 4 หมู่ที่ 7',
    'วัตถุประสงค์': 'เพื่ออำนวยความสะดวกในการสัญจรและการขนส่งผลผลิตทางการเกษตรของประชาชน',
    'เป้าหมาย (ผลผลิต)': 'ก่อสร้างถนน คสล. ผิวจราจรกว้าง 5.00 เมตร หนา 0.15 เมตร ความยาว 850 เมตร หรือมีพื้นที่ไม่น้อยกว่า 4,250 ตารางเมตร',
    'งบประมาณ 2571': 2450000,
    'งบประมาณ 2572': 0,
    'งบประมาณ 2573': 0,
    'งบประมาณ 2574': 0,
    'งบประมาณ 2575': 0,
    'ผลที่คาดว่าจะได้รับ': 'ประชาชนสัญจรได้อย่างสะดวกรวดเร็วและปลอดภัย ลดอุบัติเหตุในการเดินทาง',
    'หน่วยงานรับผิดชอบหลัก': 'กองช่าง',
    'ประเภทรายการ': 'ฉบับแรก',
    'สถานะดำเนินงาน': 'อยู่ระหว่างดำเนินการ'
  });

  saveProjectRecord({
    ID: 2,
    'ปี พ.ศ.': 2571,
    'ประเด็นการพัฒนา': '2. การส่งเสริมคุณภาพชีวิตและการศึกษา',
    'แผนงาน': 'แผนงานการศึกษา',
    'ชื่อโครงการ': 'โครงการพัฒนาศูนย์การเรียนรู้ดิจิทัลชุมชนและห้องสมุดอัจฉริยะ',
    'วัตถุประสงค์': 'เพื่อส่งเสริมการเข้าถึงองค์ความรู้และทักษะดิจิทัลสำหรับเด็ก เยาวชน และประชาชน',
    'เป้าหมาย (ผลผลิต)': 'จัดซื้ออุปกรณ์คอมพิวเตอร์ 30 ชุด พร้อมระบบเครือข่ายอินเทอร์เน็ตความเร็วสูงและสื่อการเรียนรู้ออนไลน์',
    'งบประมาณ 2571': 850000,
    'งบประมาณ 2572': 200000,
    'งบประมาณ 2573': 200000,
    'งบประมาณ 2574': 200000,
    'งบประมาณ 2575': 200000,
    'ผลที่คาดว่าจะได้รับ': 'เยาวชนและประชาชนสามารถเข้าถึงเทคโนโลยีเพื่อการศึกษาและพัฒนาอาชีพได้อย่างเท่าเทียม',
    'หน่วยงานรับผิดชอบหลัก': 'กองการศึกษา',
    'ประเภทรายการ': 'ฉบับแรก',
    'สถานะดำเนินงาน': 'เสร็จสิ้น'
  });

  SpreadsheetApp.getActiveSpreadsheet().toast('📥 นำเข้าชุดข้อมูลตัวอย่างเรียบร้อยแล้ว', 'สำเร็จ', 5);
}

/**
 * 9. ล้างข้อมูลทุกชีต (Reset)
 */
function resetAllSheets() {
  const ui = SpreadsheetApp.getUi();
  const resp = ui.alert('ยืนยันการล้างข้อมูล', 'คุณแน่ใจหรือไม่ว่าต้องการล้างและติดตั้งชีตใหม่ทั้งหมด?', ui.ButtonSet.YES_NO);
  if (resp === ui.Button.YES) {
    initialSetup();
    SpreadsheetApp.getActiveSpreadsheet().toast('🔄 รีเซ็ตชีตทั้งหมดเรียบร้อยแล้ว', 'แจ้งเตือน', 5);
  }
}
`;

export const AppsScriptModal: React.FC<AppsScriptModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'instructions' | 'api-test'>('code');
  const [webAppUrl, setWebAppUrl] = useState<string>('');
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const blob = new Blob([APPS_SCRIPT_CODE], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Code.gs';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleTestApi = async () => {
    if (!webAppUrl.trim()) return;
    setIsTesting(true);
    setTestResult(null);
    try {
      const url = webAppUrl.trim().includes('?') ? `${webAppUrl.trim()}&action=getAllData` : `${webAppUrl.trim()}?action=getAllData`;
      const res = await fetch(url);
      const data = await res.json();
      setTestResult(JSON.stringify(data, null, 2));
    } catch (e: any) {
      setTestResult(`❌ Error connecting to Web App: ${e.message}\nโปรดตรวจสอบว่าได้ตั้งค่าสิทธิ์ Anyone (ทุกคน) และบันทึก Web App Deployment URL ถูกต้อง`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/75 z-50 flex items-center justify-center p-2.5 sm:p-4 backdrop-blur-2xs">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white leading-tight flex items-center gap-1.5">
                Google Apps Script (GAS) Backend Connector
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-1.5 py-0.5 rounded border border-emerald-400/30">
                  Code.gs
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                โค้ดเชื่อมต่อฐานข้อมูล Google Sheets + รายงาน ผ.01/ผ.02 + REST API
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t-lg font-bold transition text-xs border-t border-x ${
              activeTab === 'code'
                ? 'bg-white border-slate-200 text-emerald-700 -mb-px'
                : 'bg-transparent border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            ชุดโค้ด Code.gs
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t-lg font-bold transition text-xs border-t border-x ${
              activeTab === 'instructions'
                ? 'bg-white border-slate-200 text-emerald-700 -mb-px'
                : 'bg-transparent border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            ขั้นตอนการติดตั้งบน Google Sheets
          </button>
          <button
            onClick={() => setActiveTab('api-test')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t-lg font-bold transition text-xs border-t border-x ${
              activeTab === 'api-test'
                ? 'bg-white border-slate-200 text-emerald-700 -mb-px'
                : 'bg-transparent border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            ทดสอบ Web App API
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {activeTab === 'code' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-slate-100 p-2.5 rounded-lg border border-slate-200">
                <div className="text-slate-700 font-semibold text-[11px] flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  รองรับ Google Sheets, แบบรายงาน ผ.01, ผ.02, ตาราง Projects, Approvals, Users
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleDownload}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-bold transition text-xs"
                  >
                    <Download className="w-3 h-3 text-slate-500" />
                    ดาวน์โหลด Code.gs
                  </button>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 px-3 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition text-xs shadow-2xs"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-white" /> คัดลอกสำเร็จ!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-white" /> คัดลอกโค้ดทั้งหมด
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Code display block */}
              <div className="relative">
                <pre className="bg-slate-900 text-emerald-300 p-4 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-[50vh] border border-slate-800 shadow-inner select-all">
                  <code>{APPS_SCRIPT_CODE}</code>
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'instructions' && (
            <div className="space-y-3 text-slate-700">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 font-semibold flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                <div>
                  <strong>ขั้นตอนการนำโค้ดไปใช้งานจริงใน Google Sheets (5 นาทีเสร็จ):</strong>
                </div>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">
                      1
                    </span>
                    สร้าง Google Spreadsheet ใหม่
                  </div>
                  <p className="text-slate-600 pl-6 text-[11px]">
                    เปิดเว็บเบราว์เซอร์ไปที่ <strong>sheets.new</strong> เพื่อสร้าง Google Spreadsheet ใหม่ และตั้งชื่อไฟล์ เช่น <em>"ฐานข้อมูลแผนพัฒนาท้องถิ่น (2571-2575) เทศบาลเมืองศิลา"</em>
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">
                      2
                    </span>
                    เปิดหน้าต่าง Google Apps Script
                  </div>
                  <p className="text-slate-600 pl-6 text-[11px]">
                    ที่แถบเมนูของ Google Sheets คลิกที่ <strong>ส่วนขยาย (Extensions)</strong> &gt; <strong>Apps Script</strong>
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">
                      3
                    </span>
                    วางโค้ด Code.gs และบันทึก
                  </div>
                  <p className="text-slate-600 pl-6 text-[11px]">
                    ลบโค้ดเริ่มต้นทั้งหมดในไฟล์ <code>Code.gs</code> แล้ววางโค้ดจากแท็บ "ชุดโค้ด Code.gs" ลงไป จากนั้นกดไอคอนบันทึก (หรือกด <code>Ctrl + S</code> / <code>Cmd + S</code>)
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">
                      4
                    </span>
                    รันฟังก์ชันติดตั้งโครงสร้างตาราง (initialSetup)
                  </div>
                  <p className="text-slate-600 pl-6 text-[11px]">
                    ที่แถบเครื่องมือด้านบน เลือกฟังก์ชัน <code>initialSetup</code> แล้วกดปุ่ม <strong>เรียกใช้ (Run)</strong> พร้อมกดยินยอมให้สิทธิ์การเข้าถึง (Review Permissions)
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">
                      5
                    </span>
                    เผยแพร่เป็น Web App (Deployment)
                  </div>
                  <p className="text-slate-600 pl-6 text-[11px]">
                    กดปุ่มสีน้ำเงิน <strong>ทำให้ใช้งานได้ (Deploy)</strong> &gt; <strong>การทำให้ใช้งานได้รายการใหม่ (New deployment)</strong>:
                    <br />• เลือกประเภท: <strong>เว็บแอป (Web app)</strong>
                    <br />• ดำเนินการในฐานะ: <strong>ฉัน (Me)</strong>
                    <br />• ผู้มีสิทธิ์เข้าถึง: <strong>ทุกคน (Anyone)</strong>
                    <br />• คัดลอก <strong>Web app URL</strong> มาใช้เชื่อมต่อกับแอปพลิเคชัน
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'api-test' && (
            <div className="space-y-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <label className="block font-bold text-slate-800">
                  ใส่ Web App URL ของ Google Apps Script:
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://script.google.com/macros/s/.../exec"
                    value={webAppUrl}
                    onChange={(e) => setWebAppUrl(e.target.value)}
                    className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    onClick={handleTestApi}
                    disabled={isTesting || !webAppUrl.trim()}
                    className="flex items-center gap-1 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold transition text-xs shadow-2xs flex-shrink-0"
                  >
                    {isTesting ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Send className="w-3.5 h-3.5" />
                    )}
                    ทดสอบเชื่อมต่อ (doGet)
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  ระบบจะทำการเรียก <code>?action=getAllData</code> เพื่อตรวจสอบว่า Google Apps Script ส่งข้อมูล Projects, Approvals, Users ออกมาอย่างถูกต้อง
                </p>
              </div>

              {testResult && (
                <div className="space-y-1">
                  <div className="font-bold text-slate-800 text-[11px]">ผลการทดสอบ API Response:</div>
                  <pre className="bg-slate-900 text-emerald-300 p-3 rounded-lg font-mono text-[11px] overflow-x-auto max-h-[35vh] border border-slate-800">
                    <code>{testResult}</code>
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            รวมฟังก์ชันเมนูพิเศษบน Google Sheets, รายงาน ผ.01, ผ.02 และ CRUD API ครบวงจร
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shadow-2xs"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
