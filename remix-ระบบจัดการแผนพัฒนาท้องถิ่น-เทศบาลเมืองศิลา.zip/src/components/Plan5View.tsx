import React, { useState } from 'react';
import {
  Plus,
  Search,
  Printer,
  Edit,
  Trash2,
  GitCompare,
  History,
  FileEdit
} from 'lucide-react';
import { Project, PlanType, OptionsData } from '../types';
import { YEARS, ORG_NAME } from '../data/initialData';
import { ProjectFormModal } from './ProjectFormModal';
import { ProjectRevisionModal } from './ProjectRevisionModal';
import { SelectProjectModal } from './SelectProjectModal';
import { PdfExportModal } from './PdfExportModal';
import { TablePagination } from './TablePagination';
import { Download } from 'lucide-react';

interface Plan5ViewProps {
  planType: PlanType;
  projects: Project[];
  options: OptionsData;
  onSaveProject: (data: Partial<Project>) => void;
  onDeleteProject: (id: number) => void;
  onAddOption: (category: string, value: string) => void;
  onViewRevisions?: (project: Project) => void;
}

export const Plan5View: React.FC<Plan5ViewProps> = ({
  planType,
  projects,
  options,
  onSaveProject,
  onDeleteProject,
  onAddOption,
  onViewRevisions
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterIssue, setFilterIssue] = useState('');
  const [filterPlan, setFilterPlan] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [sourceProjectForAction, setSourceProjectForAction] = useState<Project | null>(null);
  const [isSelectSourceModalOpen, setIsSelectSourceModalOpen] = useState(false);
  const [targetActionType, setTargetActionType] = useState<'เปลี่ยนแปลง' | 'แก้ไข'>('เปลี่ยนแปลง');
  const [revisionViewingProject, setRevisionViewingProject] = useState<Project | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);

  const [pageSize, setPageSize] = useState<number>(20);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Filter projects by current type and filters
  const filteredProjects = projects.filter((p) => {
    const matchType = (p['ประเภทรายการ'] || 'ฉบับแรก') === planType;
    if (!matchType) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = (p['ชื่อโครงการ'] || '').toLowerCase().includes(q);
      const matchObj = (p['วัตถุประสงค์'] || '').toLowerCase().includes(q);
      const matchTarget = (p['เป้าหมาย (ผลผลิต)'] || '').toLowerCase().includes(q);
      const matchResp = (p['หน่วยงานรับผิดชอบหลัก'] || '').toLowerCase().includes(q);
      const matchId = String(p.ID) === searchQuery.trim();
      if (!matchName && !matchObj && !matchTarget && !matchResp && !matchId) return false;
    }

    if (filterIssue && p['ประเด็นการพัฒนา'] !== filterIssue) return false;
    if (filterPlan && p['แผนงาน'] !== filterPlan) return false;

    return true;
  });

  // Paginated projects
  const totalPages = pageSize >= 999 || pageSize === 0 ? 1 : Math.ceil(filteredProjects.length / pageSize) || 1;
  const safePage = Math.min(currentPage, totalPages);
  const paginatedProjects =
    pageSize >= 999 || pageSize === 0
      ? filteredProjects
      : filteredProjects.slice((safePage - 1) * pageSize, safePage * pageSize);

  // Calculate totals
  const totalBudgetByYear: Record<number, number> = {
    2571: 0,
    2572: 0,
    2573: 0,
    2574: 0,
    2575: 0
  };
  let grandTotal = 0;

  filteredProjects.forEach((p) => {
    YEARS.forEach((y) => {
      const val = Number(p[`งบประมาณ ${y}` as keyof Project]) || 0;
      totalBudgetByYear[y] += val;
      grandTotal += val;
    });
  });

  const formatMoney = (n: number | undefined) => {
    const num = Number(n) || 0;
    return num > 0 ? num.toLocaleString('th-TH') : '-';
  };

  const handleOpenNew = () => {
    setEditingProject(null);
    setSourceProjectForAction(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Project) => {
    setEditingProject(p);
    setSourceProjectForAction(null);
    setIsModalOpen(true);
  };

  const handleOpenSelectSource = (type: 'เปลี่ยนแปลง' | 'แก้ไข') => {
    setTargetActionType(type);
    setIsSelectSourceModalOpen(true);
  };

  const handleSelectSourceProject = (sourceP: Project) => {
    setSourceProjectForAction(sourceP);
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleQuickChangeFromRow = (p: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setTargetActionType('เปลี่ยนแปลง');
    setSourceProjectForAction(p);
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleQuickEditFromRow = (p: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setTargetActionType('แก้ไข');
    setSourceProjectForAction(p);
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleOpenRevisions = (p: Project, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onViewRevisions) {
      onViewRevisions(p);
    } else {
      setRevisionViewingProject(p);
    }
  };

  const handleSaveModal = (data: Partial<Project>) => {
    onSaveProject(data);
    setIsModalOpen(false);
    setSourceProjectForAction(null);
  };

  return (
    <div className="space-y-2.5 flex flex-col h-full">
      {/* Compact Header & Filter Strip */}
      <div className="bg-white rounded-lg p-2.5 sm:px-3 sm:py-2 border border-slate-200 shadow-2xs space-y-2 shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
              ผ.02
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-slate-900 leading-tight flex items-center gap-1.5">
                <span>บัญชีรายละเอียดโครงการพัฒนาท้องถิ่น (แบบ ผ.02)</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  {planType} ({filteredProjects.length} โครงการ)
                </span>
              </h2>
              <p className="text-[10px] text-slate-500">
                แผนพัฒนาท้องถิ่น (พ.ศ. 2571-2575) | {ORG_NAME}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 ml-auto no-print">
            <button
              onClick={() => setIsPdfModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-2xs transition"
            >
              <Download className="w-3 h-3" />
              ส่งออก PDF
            </button>

            <button
              onClick={() => window.print()}
              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100 text-[11px] font-bold transition"
            >
              <Printer className="w-3 h-3 text-slate-600" />
              พิมพ์
            </button>

            {/* Plan-specific Action Buttons */}
            {planType === 'เปลี่ยนแปลง' ? (
              <button
                type="button"
                onClick={() => handleOpenSelectSource('เปลี่ยนแปลง')}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-bold shadow-2xs transition"
              >
                <GitCompare className="w-3 h-3" />
                เลือกโครงการเพื่อเปลี่ยนแปลง
              </button>
            ) : planType === 'แก้ไข' ? (
              <button
                type="button"
                onClick={() => handleOpenSelectSource('แก้ไข')}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold shadow-2xs transition"
              >
                <FileEdit className="w-3 h-3" />
                เลือกโครงการเพื่อขอแก้ไข
              </button>
            ) : (
              <button
                type="button"
                onClick={handleOpenNew}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-2xs transition"
              >
                <Plus className="w-3 h-3" />
                เพิ่มโครงการ ({planType})
              </button>
            )}
          </div>
        </div>

        {/* Compact Search & Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-100 no-print">
          {/* Search bar */}
          <div className="relative sm:col-span-2">
            <Search className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ค้นหาชื่อโครงการ, วัตถุประสงค์, รหัส..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 text-xs rounded-md pl-7 pr-2 py-1 text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Filter Issue */}
          <div>
            <select
              value={filterIssue}
              onChange={(e) => {
                setFilterIssue(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 text-xs rounded-md px-2 py-1 text-slate-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 truncate"
            >
              <option value="">-- ทุกประเด็นพัฒนา --</option>
              {(options['ประเด็นการพัฒนา'] || []).map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </div>

          {/* Filter Plan */}
          <div>
            <select
              value={filterPlan}
              onChange={(e) => {
                setFilterPlan(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 text-xs rounded-md px-2 py-1 text-slate-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 truncate"
            >
              <option value="">-- ทุกแผนงาน --</option>
              {(options['แผนงาน'] || []).map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Official Form ผ.02 Table with Dedicated Screen-Fitting Scroll Container */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-2xs overflow-hidden flex flex-col flex-1 min-h-0">
        <div className="overflow-auto max-h-[calc(100vh-210px)] flex-1 custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="sticky top-0 z-20">
              <tr className="bg-slate-800 text-white border-b border-slate-700 shadow-xs">
                <th rowSpan={2} className="py-1.5 px-1.5 text-center border-r border-slate-700 min-w-[80px] font-bold no-print bg-slate-800">
                  จัดการ
                </th>
                <th rowSpan={2} className="py-1.5 px-1.5 text-center border-r border-slate-700 w-9 font-bold bg-slate-800">
                  ที่
                </th>
                <th rowSpan={2} className="py-1.5 px-2 border-r border-slate-700 min-w-[200px] font-bold bg-slate-800">
                  โครงการ
                </th>
                <th rowSpan={2} className="py-1.5 px-2 border-r border-slate-700 min-w-[140px] font-bold bg-slate-800">
                  วัตถุประสงค์
                </th>
                <th rowSpan={2} className="py-1.5 px-2 border-r border-slate-700 min-w-[140px] font-bold bg-slate-800">
                  เป้าหมาย (ผลผลิต)
                </th>
                <th
                  colSpan={YEARS.length}
                  className="py-1 px-1.5 text-center border-r border-slate-700 font-bold bg-slate-900"
                >
                  งบประมาณ (บาท)
                </th>
                <th rowSpan={2} className="py-1.5 px-2 border-r border-slate-700 min-w-[130px] font-bold bg-slate-800">
                  ผลที่คาดว่าจะได้รับ
                </th>
                <th rowSpan={2} className={`py-1.5 px-2 ${planType !== 'ฉบับแรก' ? 'border-r border-slate-700' : 'border-slate-700'} min-w-[110px] font-bold bg-slate-800`}>
                  หน่วยงานหลัก
                </th>
                {planType !== 'ฉบับแรก' && (
                  <th rowSpan={2} className="py-1.5 px-2 border-slate-700 min-w-[150px] font-bold bg-slate-800">
                    เหตุผลความจำเป็น
                  </th>
                )}
              </tr>
              <tr className="bg-slate-900 text-white border-b border-slate-700">
                {YEARS.map((y) => (
                  <th
                    key={y}
                    className="py-1 px-1 text-center border-r border-slate-700 font-bold text-[10px] min-w-[70px] bg-slate-900"
                  >
                    พ.ศ. {y}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedProjects.length > 0 ? (
                paginatedProjects.map((p, idx) => {
                  const globalIdx = pageSize === 0 ? idx : (safePage - 1) * pageSize + idx;
                  return (
                    <tr
                      key={p.ID}
                      className="hover:bg-emerald-50/60 transition group cursor-pointer"
                      onClick={() => handleOpenEdit(p)}
                    >
                      {/* Actions Column (First column) */}
                      <td
                        className="py-1 px-1 text-center border-r border-slate-100 no-print"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-center gap-0.5 flex-wrap max-w-[100px] mx-auto">
                          {(planType === 'ฉบับแรก' || planType === 'เพิ่มเติม') && (
                            <>
                              <button
                                type="button"
                                onClick={(e) => handleQuickChangeFromRow(p, e)}
                                title="ขอเปลี่ยนแปลงโครงการนี้"
                                className="p-0.5 rounded bg-purple-100 text-purple-800 hover:bg-purple-200 border border-purple-300 transition"
                              >
                                <GitCompare className="w-2.5 h-2.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => handleQuickEditFromRow(p, e)}
                                title="ขอแก้ไขโครงการนี้"
                                className="p-0.5 rounded bg-amber-100 text-amber-800 hover:bg-amber-200 border border-amber-300 transition"
                              >
                                <FileEdit className="w-2.5 h-2.5" />
                              </button>
                            </>
                          )}

                          <button
                            onClick={(e) => handleOpenRevisions(p, e)}
                            title="ดูประวัติไทม์ไลน์"
                            className="p-0.5 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 transition"
                          >
                            <History className="w-2.5 h-2.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(p)}
                            title="แก้ไขข้อมูล"
                            className="p-0.5 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition"
                          >
                            <Edit className="w-2.5 h-2.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`ยืนยันการลบโครงการ #${p.ID} (${p['ชื่อโครงการ']}) หรือไม่?`)) {
                                onDeleteProject(p.ID);
                              }
                            }}
                            title="ลบโครงการ"
                            className="p-0.5 rounded bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition"
                          >
                            <Trash2 className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </td>

                      <td className="py-1 px-1 text-center font-bold text-slate-800 border-r border-slate-100 font-mono text-[11px]">
                        {globalIdx + 1}
                      </td>
                      <td className="py-1 px-2 font-semibold text-slate-900 border-r border-slate-100">
                        <div className="font-bold text-slate-900 group-hover:text-emerald-700 leading-tight">
                          {p['ชื่อโครงการ']}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {p['ประเด็นการพัฒนา']}
                        </div>
                      </td>
                      <td className="py-1 px-2 text-slate-600 border-r border-slate-100 line-clamp-2 leading-snug text-[11px]">
                        {p['วัตถุประสงค์'] || '-'}
                      </td>
                      <td className="py-1 px-2 text-slate-600 border-r border-slate-100 line-clamp-2 leading-snug text-[11px]">
                        {p['เป้าหมาย (ผลผลิต)'] || '-'}
                      </td>

                      {/* 5-Year Budget Columns */}
                      {YEARS.map((y) => {
                        const val = Number(p[`งบประมาณ ${y}` as keyof Project]) || 0;
                        return (
                          <td
                            key={y}
                            className="py-1 px-1.5 text-right font-mono text-slate-800 border-r border-slate-100 font-medium whitespace-nowrap text-[11px]"
                          >
                            {formatMoney(val)}
                          </td>
                        );
                      })}

                      <td className="py-1 px-2 text-slate-600 border-r border-slate-100 line-clamp-2 leading-snug text-[11px]">
                        {p['ผลที่คาดว่าจะได้รับ'] || '-'}
                      </td>
                      <td className={`py-1 px-2 text-slate-700 font-medium text-[11px] truncate max-w-[120px] ${planType !== 'ฉบับแรก' ? 'border-r border-slate-100' : 'border-slate-100'}`}>
                        {p['หน่วยงานรับผิดชอบหลัก'] || '-'}
                      </td>
                      {planType !== 'ฉบับแรก' && (
                        <td className="py-1 px-2 text-slate-700 font-normal border-slate-100 line-clamp-2 leading-snug text-[11px]">
                          {p['เหตุผลและความจำเป็น'] || p['เหตุผลความจำเป็น'] || '-'}
                        </td>
                      )}
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td
                    colSpan={6 + YEARS.length + (planType !== 'ฉบับแรก' ? 1 : 0)}
                    className="p-6 text-center text-slate-400 text-xs"
                  >
                    ยังไม่มีข้อมูลโครงการประเภท "{planType}" ที่ตรงกับเงื่อนไข
                  </td>
                </tr>
              )}
            </tbody>
            {/* Sticky Subtotal Footer */}
            {filteredProjects.length > 0 && (
              <tfoot className="sticky bottom-0 z-20">
                <tr className="bg-emerald-800 text-white font-bold border-t-2 border-emerald-400 shadow-md">
                  <td colSpan={5} className="py-1.5 px-2 text-right text-white border-r border-emerald-700 text-xs">
                    รวมงบประมาณทั้งสิ้น ({filteredProjects.length} โครงการ)
                  </td>
                  {YEARS.map((y) => (
                    <td
                      key={y}
                      className="py-1.5 px-1.5 text-right font-mono text-emerald-200 border-r border-emerald-700 font-extrabold whitespace-nowrap text-xs"
                    >
                      {formatMoney(totalBudgetByYear[y])}
                    </td>
                  ))}
                  <td colSpan={planType !== 'ฉบับแรก' ? 3 : 2} className="py-1.5 px-2 text-white font-mono text-right text-xs">
                    รวม 5 ปี: {grandTotal.toLocaleString('th-TH')} บ.
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Table Footer - Standard Pagination */}
        {filteredProjects.length > 0 && (
          <TablePagination
            currentPage={safePage}
            totalItems={filteredProjects.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
            pageSizeOptions={[10, 20, 50, 100, 999]}
          />
        )}
      </div>

      {/* Modal Form */}
      {isModalOpen && (
        <ProjectFormModal
          project={editingProject}
          sourceProject={sourceProjectForAction}
          planType={sourceProjectForAction ? targetActionType : planType}
          options={options}
          onSave={handleSaveModal}
          onDelete={(id) => {
            onDeleteProject(id);
            setIsModalOpen(false);
          }}
          onClose={() => {
            setIsModalOpen(false);
            setSourceProjectForAction(null);
          }}
          onAddOption={onAddOption}
        />
      )}

      {/* Select Source Project Modal for Change / Edit operations */}
      {isSelectSourceModalOpen && (
        <SelectProjectModal
          projects={projects}
          targetPlanType={targetActionType}
          onSelectProject={(selectedP) => {
            setIsSelectSourceModalOpen(false);
            handleSelectSourceProject(selectedP);
          }}
          onClose={() => setIsSelectSourceModalOpen(false)}
        />
      )}

      {/* Revision Timeline & Diff Modal */}
      {revisionViewingProject && (
        <ProjectRevisionModal
          project={revisionViewingProject}
          onClose={() => setRevisionViewingProject(null)}
          onCreateNewRevision={(p) => {
            setRevisionViewingProject(null);
            setEditingProject(p);
            setSourceProjectForAction(null);
            setIsModalOpen(true);
          }}
        />
      )}

      {/* PDF Export & Page Setup Modal */}
      <PdfExportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        projects={projects}
        initialReportType={
          planType === 'เพิ่มเติม'
            ? 'ผ02-additional'
            : planType === 'เปลี่ยนแปลง'
            ? 'change-diff'
            : planType === 'แก้ไข'
            ? 'edit-diff'
            : 'ผ02-baseline'
        }
      />
    </div>
  );
};
